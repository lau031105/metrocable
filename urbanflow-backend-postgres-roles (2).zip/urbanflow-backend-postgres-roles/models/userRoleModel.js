import { DataTypes } from "sequelize";
import { sequelize } from "../db/connection.js";
import { User } from "./userModel.js";
import { Role } from "./roleModel.js";

export const UserRole = sequelize.define("UserRole", {
  id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
}, {
  timestamps: true,
  tableName: "user_roles"
});

// Relaciones N:N
User.belongsToMany(Role, { through: UserRole, foreignKey: "user_id" });
Role.belongsToMany(User, { through: UserRole, foreignKey: "role_id" });
