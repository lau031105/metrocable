import express from "express";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import { connectDB, sequelize } from "./db/connection.js";
import userRoutes from "./routes/userRoutes.js";
import roleRoutes from "./routes/roleRoutes.js";
import errorHandler from "./middlewares/errorHandler.js";
import { User } from "./models/userModel.js";
import { Role } from "./models/roleModel.js";
import { UserRole } from "./models/userRoleModel.js";

dotenv.config();
const app = express();

// Directorios
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");
app.use(express.static(path.join(__dirname, "public")));

// Middlewares
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rutas
app.use("/api/users", userRoutes);
app.use("/api/roles", roleRoutes);
app.get("/", (req, res) => res.render("index", { title: "UrbanFlow" }));

// Global error handler
app.use(errorHandler);

// Iniciar servidor y BD
connectDB().then(async () => {
  await sequelize.sync({ alter: true });
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () =>
    console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`)
  );
});
