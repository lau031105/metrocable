import express from "express";
import { createRole, listRoles, getRole, updateRole, deleteRole } from "../controllers/roleController.js";

const router = express.Router();
router.post("/create", createRole);
router.get("/", listRoles);
router.get("/:id", getRole);
router.put("/:id", updateRole);
router.delete("/:id", deleteRole);

export default router;
