import express from "express";
import { registerUser, listUsers, getUser, updateUser, deleteUser, loginUser } from "../controllers/userController.js";
import { assignRoles, removeRole } from "../controllers/userRoleController.js";
import { requireFields } from "../middlewares/validateInput.js";

const router = express.Router();
router.post("/register", requireFields("name", "email", "password"), registerUser);
router.post("/login", loginUser);
router.get("/", listUsers);
router.get("/:id", getUser);
router.put("/:id", updateUser);
router.delete("/:id", deleteUser);

// Assign / remove roles
router.post("/:id/roles", assignRoles);
router.delete("/:id/roles/:roleId", removeRole);

export default router;
