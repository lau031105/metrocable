import { Role } from "../models/roleModel.js";

export const createRole = async (req, res) => {
  try {
    const { name, description } = req.body;
    const role = await Role.create({ name, description });
    res.status(201).json({ message: "Rol creado", role });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const listRoles = async (req, res) => {
  try {
    const roles = await Role.findAll();
    res.json(roles);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const getRole = async (req, res) => {
  try {
    const { id } = req.params;
    const role = await Role.findByPk(id);
    if (!role) return res.status(404).json({ error: "Rol no encontrado" });
    res.json(role);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const updateRole = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, description } = req.body;
    const role = await Role.findByPk(id);
    if (!role) return res.status(404).json({ error: "Rol no encontrado" });
    if (name) role.name = name;
    if (description) role.description = description;
    await role.save();
    res.json({ message: "Rol actualizado", role });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const deleteRole = async (req, res) => {
  try {
    const { id } = req.params;
    const role = await Role.findByPk(id);
    if (!role) return res.status(404).json({ error: "Rol no encontrado" });
    await role.destroy();
    res.json({ message: "Rol eliminado" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
