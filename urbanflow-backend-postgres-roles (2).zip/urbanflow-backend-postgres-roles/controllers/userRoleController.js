import { User } from "../models/userModel.js";
import { Role } from "../models/roleModel.js";
import { sequelize } from "../db/connection.js";

export const assignRoles = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { id } = req.params; // user id
    const { roles } = req.body; // array of role ids
    if (!Array.isArray(roles)) return res.status(400).json({ error: "roles debe ser un array de ids" });

    const user = await User.findByPk(id, { transaction: t });
    if (!user) {
      await t.rollback();
      return res.status(404).json({ error: "Usuario no encontrado" });
    }

    const roleRecords = await Role.findAll({ where: { id: roles }, transaction: t });
    await user.setRoles(roleRecords, { transaction: t });
    await t.commit();
    const updated = await User.findByPk(id, { include: Role });
    res.json({ message: "Roles asignados", user: updated });
  } catch (error) {
    await t.rollback();
    res.status(500).json({ error: error.message });
  }
};

export const removeRole = async (req, res) => {
  try {
    const { id, roleId } = req.params;
    const user = await User.findByPk(id);
    if (!user) return res.status(404).json({ error: "Usuario no encontrado" });
    const role = await Role.findByPk(roleId);
    if (!role) return res.status(404).json({ error: "Rol no encontrado" });
    await user.removeRole(role);
    const updated = await User.findByPk(id, { include: Role });
    res.json({ message: "Rol quitado", user: updated });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
